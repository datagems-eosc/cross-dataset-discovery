from cross_dataset_discovery.foo import foo


def test_foo():
    assert foo("foo") == "foo"
